#include "plotwgt.h"

plotwgt::plotwgt()
{

}

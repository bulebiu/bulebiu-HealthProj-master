#ifndef PLOTWGT_H
#define PLOTWGT_H


class plotwgt
{
public:
    plotwgt();
};

#endif // PLOTWGT_H
